import ExpoModulesCore
import Foundation

public class BatteryInfoModule: Module {
  public func definition() -> ModuleDefinition {
    Name("BatteryInfoModule")

    Function("getBatteryInfo") { () -> [String: Any] in
      return self.readIOKitBatteryInfo()
    }
  }

  private func readIOKitBatteryInfo() -> [String: Any] {
    var result: [String: Any] = [:]

    guard let iokit = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_NOW) else {
      return result
    }
    defer { dlclose(iokit) }

    typealias IOServiceGetMatchingServiceFunc = @convention(c) (UInt32, CFMutableDictionary?) -> UInt32
    typealias IOServiceMatchingFunc = @convention(c) (UnsafePointer<CChar>) -> CFMutableDictionary?
    typealias IORegistryEntryCreateCFPropertiesFunc = @convention(c) (UInt32, UnsafeMutablePointer<CFMutableDictionary?>, CFAllocator?, UInt32) -> Int32
    typealias IOObjectReleaseFunc = @convention(c) (UInt32) -> Int32

    guard let getServiceSym = dlsym(iokit, "IOServiceGetMatchingService"),
          let matchingSym = dlsym(iokit, "IOServiceMatching"),
          let propsSym = dlsym(iokit, "IORegistryEntryCreateCFProperties"),
          let releaseSym = dlsym(iokit, "IOObjectRelease") else {
      return result
    }

    let IOServiceGetMatchingService = unsafeBitCast(getServiceSym, to: IOServiceGetMatchingServiceFunc.self)
    let IOServiceMatching = unsafeBitCast(matchingSym, to: IOServiceMatchingFunc.self)
    let IORegistryEntryCreateCFProperties = unsafeBitCast(propsSym, to: IORegistryEntryCreateCFPropertiesFunc.self)
    let IOObjectRelease = unsafeBitCast(releaseSym, to: IOObjectReleaseFunc.self)

    let kIOMainPortDefault: UInt32 = 0
    guard let matching = IOServiceMatching("AppleSmartBattery") else { return result }
    let service = IOServiceGetMatchingService(kIOMainPortDefault, matching)
    guard service != 0 else { return result }
    defer { _ = IOObjectRelease(service) }

    var props: CFMutableDictionary?
    let status = IORegistryEntryCreateCFProperties(service, &props, kCFAllocatorDefault, 0)
    guard status == 0, let properties = props as? [String: Any] else { return result }

    if let cycle = properties["CycleCount"] as? Int { result["cycleCount"] = cycle }
    if let design = properties["DesignCapacity"] as? Int { result["designCapacity"] = design }
    if let max = properties["MaxCapacity"] as? Int { result["maxCapacity"] = max }
    if let temp = properties["Temperature"] as? Int { result["temperature"] = Double(temp) / 100.0 }
    if let volt = properties["Voltage"] as? Int { result["voltage"] = Double(volt) / 1000.0 }
    if let amp = properties["Amperage"] as? Int { result["amperage"] = amp }

    return result
  }
}
