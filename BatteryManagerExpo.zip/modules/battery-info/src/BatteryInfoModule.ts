import { requireNativeModule } from 'expo-modules-core';

export interface BatteryInfo {
  cycleCount: number;
  designCapacity: number;
  maxCapacity: number;
  temperature: number;
  voltage: number;
  amperage: number;
}

const BatteryInfoModule = requireNativeModule('BatteryInfoModule');

export function getBatteryInfo(): BatteryInfo {
  return BatteryInfoModule.getBatteryInfo();
}
