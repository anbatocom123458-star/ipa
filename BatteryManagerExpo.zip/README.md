# 🔋 Battery Manager (Expo + React Native)

Ứng dụng quản lý pin iOS viết bằng **React Native (TSX)** + **Expo**.
Build IPA dễ dàng qua **EAS Build** (cloud, không cần Mac, không cần certificate).

## ✨ Tính năng

- UI bằng TSX với animation Reanimated
- Thông số pin chuyên sâu qua IOKit (native module Swift)
- Thông báo push notification
- Lịch sử sạc, thống kê sử dụng
- Build IPA trên cloud (EAS) — không cần macOS runner

## 🚀 Cách dùng

### 1. Cài đặt local
```bash
npm install
npx expo start
```

### 2. Build IPA trên cloud (EAS)
```bash
# Cài EAS CLI
npm install -g eas-cli

# Đăng nhập Expo (miễn phí)
eas login

# Build IPA
 eas build --platform ios --profile preview
```

### 3. Build tự động qua GitHub Actions
- Tạo tài khoản [expo.dev](https://expo.dev)
- Vào **Account Settings → Access Tokens → Create**
- Thêm `EXPO_TOKEN` vào GitHub Secrets
- Push lên `main` → Actions tự động build IPA

## 📱 Cài IPA lên iPhone

Sau khi EAS build xong, tải IPA về cài qua:
- **AltStore** (khuyên dùng)
- **Sideloadly**
- **Apple Configurator 2**

## 🛠 Stack

- React Native 0.74
- Expo SDK 51
- TypeScript / TSX
- Reanimated (animation)
- React Native SVG
- Expo Battery + Notifications
- Custom Expo Module (Swift + IOKit)

## ⚠️ Lưu ý

- EAS Build miễn phí: 30 builds iOS/tháng
- IOKit là private API → không lên App Store được, chỉ dùng cho sideload
- Cần Apple ID (miễn phí) để cài qua AltStore
