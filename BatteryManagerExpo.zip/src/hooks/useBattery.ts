import { useState, useEffect, useCallback } from 'react';
import * as Battery from 'expo-battery';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getBatteryInfo } from '../../modules/battery-info/src/BatteryInfoModule';

export interface ChargeSession {
  id: string;
  startTime: number;
  endTime: number;
  startLevel: number;
  endLevel: number;
  duration: number;
}

export interface BatteryData {
  level: number;
  state: Battery.BatteryState;
  cycleCount: number;
  designCapacity: number;
  maxCapacity: number;
  temperature: number;
  voltage: number;
  amperage: number;
  healthPercentage: number;
  isCharging: boolean;
  isFullyCharged: boolean;
  totalUsageHours: number;
  chargeCount: number;
  lastChargeDuration: number;
  chargeHistory: ChargeSession[];
}

const STORAGE_KEYS = {
  CHARGE_HISTORY: '@charge_history',
  CHARGE_COUNT: '@charge_count',
  USAGE_HOURS: '@usage_hours',
  LAST_CHECK: '@last_check',
};

export function useBattery() {
  const [data, setData] = useState<BatteryData>({
    level: 0,
    state: Battery.BatteryState.UNKNOWN,
    cycleCount: 0,
    designCapacity: 0,
    maxCapacity: 0,
    temperature: 0,
    voltage: 0,
    amperage: 0,
    healthPercentage: 100,
    isCharging: false,
    isFullyCharged: false,
    totalUsageHours: 0,
    chargeCount: 0,
    lastChargeDuration: 0,
    chargeHistory: [],
  });

  const loadHistory = useCallback(async () => {
    try {
      const [historyJson, count, hours] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.CHARGE_HISTORY),
        AsyncStorage.getItem(STORAGE_KEYS.CHARGE_COUNT),
        AsyncStorage.getItem(STORAGE_KEYS.USAGE_HOURS),
      ]);
      const history = historyJson ? JSON.parse(historyJson) : [];
      setData(prev => ({
        ...prev,
        chargeHistory: history,
        chargeCount: parseInt(count || '0', 10),
        totalUsageHours: parseFloat(hours || '0'),
      }));
    } catch {}
  }, []);

  const updateInfo = useCallback(async () => {
    const level = await Battery.getBatteryLevelAsync();
    const state = await Battery.getBatteryStateAsync();
    const iokitInfo = getBatteryInfo();

    const isCharging = state === Battery.BatteryState.CHARGING || state === Battery.BatteryState.FULL;
    const isFullyCharged = state === Battery.BatteryState.FULL;

    let health = 100;
    if (iokitInfo.designCapacity > 0) {
      health = (iokitInfo.maxCapacity / iokitInfo.designCapacity) * 100;
    }

    // Accumulate usage time
    const now = Date.now();
    const lastCheckStr = await AsyncStorage.getItem(STORAGE_KEYS.LAST_CHECK);
    const lastCheck = lastCheckStr ? parseInt(lastCheckStr, 10) : now;
    const interval = (now - lastCheck) / 1000;
    let totalHours = data.totalUsageHours;
    if (interval > 0 && interval < 300) {
      totalHours += interval / 3600;
      await AsyncStorage.setItem(STORAGE_KEYS.USAGE_HOURS, totalHours.toString());
    }
    await AsyncStorage.setItem(STORAGE_KEYS.LAST_CHECK, now.toString());

    setData(prev => ({
      ...prev,
      level: Math.round(level * 100),
      state,
      ...iokitInfo,
      healthPercentage: health,
      isCharging,
      isFullyCharged,
      totalUsageHours: totalHours,
    }));
  }, [data.totalUsageHours]);

  useEffect(() => {
    loadHistory();
    updateInfo();

    const interval = setInterval(updateInfo, 5000);
    const sub = Battery.addBatteryLevelListener(updateInfo);
    const sub2 = Battery.addBatteryStateListener(updateInfo);

    return () => {
      clearInterval(interval);
      sub.remove();
      sub2.remove();
    };
  }, [loadHistory, updateInfo]);

  return data;
}
