import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import Animated, { FadeInUp, FadeIn } from 'react-native-reanimated';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width } = Dimensions.get('window');

const PAGES = [
  { icon: '⚡', color: '#4ade80', title: 'Chào mừng đến\nBattery Manager', desc: 'Ứng dụng giúp bạn theo dõi và quản lý sức khỏe pin iPhone một cách chi tiết nhất.' },
  { icon: '📊', color: '#60a5fa', title: 'Thống kê chuyên sâu', desc: 'Xem số chu kỳ sạc, thời gian sử dụng, lịch sử sạc và tình trạng pin hiện tại.' },
  { icon: '🔔', color: '#fb923c', title: 'Thông báo thông minh', desc: 'Nhận cảnh báo khi sử dụng thiết bị quá nhiều hoặc pin đạt ngưỡng nguy hiểm.' },
  { icon: '🛡️', color: '#c084fc', title: 'Bảo vệ pin lâu dài', desc: 'Gợi ý tối ưu dựa trên thói quen sạc của bạn để kéo dài tuổi thọ pin.' },
];

export default function WelcomeScreen({ onComplete }: { onComplete: () => void }) {
  const [page, setPage] = useState(0);

  const handleNext = async () => {
    if (page < PAGES.length - 1) {
      setPage(p => p + 1);
    } else {
      await AsyncStorage.setItem('@has_seen_welcome', 'true');
      onComplete();
    }
  };

  const current = PAGES[page];

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Animated.View key={page} entering={FadeInUp.duration(500)} style={styles.page}>
          <View style={[styles.iconCircle, { borderColor: current.color + '40' }]}>
            <Text style={[styles.icon, { color: current.color }]}>{current.icon}</Text>
          </View>
          <Text style={styles.title}>{current.title}</Text>
          <Text style={styles.desc}>{current.desc}</Text>
        </Animated.View>
      </View>

      <View style={styles.footer}>
        <View style={styles.dots}>
          {PAGES.map((_, i) => (
            <View key={i} style={[styles.dot, i === page && { width: 24, backgroundColor: '#fff' }]} />
          ))}
        </View>

        <TouchableOpacity onPress={handleNext} activeOpacity={0.8}>
          <View style={styles.button}>
            <Text style={styles.buttonText}>
              {page < PAGES.length - 1 ? 'Tiếp theo →' : 'Bắt đầu sử dụng ✓'}
            </Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0f0a', justifyContent: 'space-between' },
  content: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 32 },
  page: { alignItems: 'center', width: width - 64 },
  iconCircle: { width: 140, height: 140, borderRadius: 70, borderWidth: 2, justifyContent: 'center', alignItems: 'center', marginBottom: 32 },
  icon: { fontSize: 56 },
  title: { fontSize: 28, fontWeight: 'bold', color: '#fff', textAlign: 'center', marginBottom: 16, lineHeight: 36 },
  desc: { fontSize: 16, color: '#ffffffaa', textAlign: 'center', lineHeight: 24 },
  footer: { paddingHorizontal: 28, paddingBottom: 48 },
  dots: { flexDirection: 'row', justifyContent: 'center', marginBottom: 32, gap: 8 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#ffffff40' },
  button: { backgroundColor: '#4ade80', borderRadius: 20, paddingVertical: 18, alignItems: 'center' },
  buttonText: { color: '#000', fontSize: 17, fontWeight: '600' },
});
