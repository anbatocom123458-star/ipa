import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { useBattery } from '../hooks/useBattery';
import BatteryRing from '../components/BatteryRing';
import StatCard from '../components/StatCard';
import GlassCard from '../components/GlassCard';

export default function DashboardScreen() {
  const battery = useBattery();
  const [tab, setTab] = useState<'dashboard' | 'history' | 'settings'>('dashboard');

  const statusText = battery.isFullyCharged ? 'Đã đầy' : battery.isCharging ? 'Đang sạc' : 'Đang dùng pin';
  const statusColor = battery.isCharging ? '#4ade80' : battery.level <= 20 ? '#ef4444' : '#3b82f6';

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} style={styles.scroll}>
        <Text style={styles.header}>Battery Manager</Text>

        <BatteryRing level={battery.level} isCharging={battery.isCharging} statusText={statusText} />

        <View style={styles.grid}>
          <StatCard icon="⚡" color="#fbbf24" title="Số lần sạc" value={String(battery.chargeCount)} unit="lần" />
          <StatCard icon="⏱️" color="#60a5fa" title="Thời gian sử dụng" value={battery.totalUsageHours.toFixed(1)} unit="giờ" />
          <StatCard icon="🔄" color="#c084fc" title="Chu kỳ sạc" value={String(battery.cycleCount)} unit="chu kỳ" />
          <StatCard icon="❤️" color="#f87171" title="Sức khỏe pin" value={String(Math.round(battery.healthPercentage))} unit="%" />
        </View>

        <GlassCard>
          <Text style={styles.sectionTitle}>📋 Thông số chi tiết</Text>
          <DetailRow icon="🌡️" color="#fb923c" label="Nhiệt độ pin" value={`${battery.temperature.toFixed(1)}°C`} />
          <DetailRow icon="⚡" color="#fbbf24" label="Điện áp" value={`${battery.voltage.toFixed(2)}V`} />
          <DetailRow icon="〰️" color="#22d3ee" label="Dòng điện" value={`${battery.amperage} mA`} />
          <DetailRow icon="📦" color="#94a3b8" label="Dung lượng thiết kế" value={`${battery.designCapacity} mAh`} />
          <DetailRow icon="📦" color="#4ade80" label="Dung lượng tối đa" value={`${battery.maxCapacity} mAh`} />
        </GlassCard>

        <View style={[styles.statusBanner, { backgroundColor: statusColor + '18', borderColor: statusColor + '30' }]}>
          <Text style={[styles.statusText, { color: statusColor }]}>{statusText}</Text>
          {battery.isCharging && !battery.isFullyCharged && (
            <Text style={styles.statusSub}>Đang sạc {battery.level}%</Text>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

function DetailRow({ icon, color, label, value }: { icon: string; color: string; label: string; value: string }) {
  return (
    <View style={styles.detailRow}>
      <Text style={styles.detailIcon}>{icon}</Text>
      <Text style={styles.detailLabel}>{label}</Text>
      <Text style={[styles.detailValue, { color }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0f0a' },
  scroll: { paddingHorizontal: 16 },
  header: { fontSize: 28, fontWeight: 'bold', color: '#fff', marginTop: 60, marginBottom: 20 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 20 },
  sectionTitle: { fontSize: 17, fontWeight: 'bold', color: '#fff', marginBottom: 16 },
  statusBanner: { borderRadius: 20, padding: 16, marginBottom: 40, borderWidth: 1 },
  statusText: { fontSize: 15, fontWeight: '600' },
  statusSub: { fontSize: 12, color: '#ffffff80', marginTop: 4 },
  detailRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10 },
  detailIcon: { fontSize: 16, width: 28 },
  detailLabel: { flex: 1, fontSize: 14, color: '#ffffff90' },
  detailValue: { fontSize: 14, fontWeight: '600' },
});
