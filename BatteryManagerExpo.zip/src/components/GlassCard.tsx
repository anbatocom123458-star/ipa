import React from 'react';
import { View, StyleSheet } from 'react-native';

export default function GlassCard({ children }: { children: React.ReactNode }) {
  return (
    <View style={styles.card}>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: '#ffffff08', borderRadius: 24, padding: 16, borderWidth: 1, borderColor: '#ffffff10', marginBottom: 16 },
});
