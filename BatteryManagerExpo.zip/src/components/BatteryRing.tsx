import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Circle } from 'react-native-svg';

export default function BatteryRing({ level, isCharging, statusText }: { level: number; isCharging: boolean; statusText: string }) {
  const size = 220;
  const stroke = 20;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = (level / 100) * circumference;

  const color = level <= 20 ? '#ef4444' : level <= 50 ? '#fbbf24' : '#4ade80';

  return (
    <View style={styles.container}>
      <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <Circle cx={size/2} cy={size/2} r={radius} stroke="#ffffff10" strokeWidth={stroke} fill="none" />
        <Circle
          cx={size/2} cy={size/2} r={radius}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${progress} ${circumference}`}
          transform={`rotate(-90 ${size/2} ${size/2})`}
        />
      </Svg>
      <View style={styles.inner}>
        <Text style={styles.percent}>{level}%</Text>
        <View style={[styles.badge, { backgroundColor: color + '20' }]}>
          <Text style={[styles.badgeText, { color }]}>{statusText}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignSelf: 'center', marginVertical: 20, width: 220, height: 220, justifyContent: 'center', alignItems: 'center' },
  inner: { position: 'absolute', alignItems: 'center' },
  percent: { fontSize: 48, fontWeight: 'bold', color: '#fff' },
  badge: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12, marginTop: 6 },
  badgeText: { fontSize: 12, fontWeight: '600' },
});
