import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function StatCard({ icon, color, title, value, unit }: { icon: string; color: string; title: string; value: string; unit: string }) {
  return (
    <View style={[styles.card, { borderColor: color + '20' }]}>
      <Text style={[styles.icon, { color }]}>{icon}</Text>
      <Text style={styles.value}>{value}</Text>
      <Text style={styles.unit}>{unit}</Text>
      <Text style={styles.title}>{title}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { width: '47%', backgroundColor: '#ffffff06', borderRadius: 18, padding: 14, borderWidth: 1, marginBottom: 12 },
  icon: { fontSize: 20, marginBottom: 8 },
  value: { fontSize: 22, fontWeight: 'bold', color: '#fff' },
  unit: { fontSize: 11, color: '#888', marginBottom: 4 },
  title: { fontSize: 11, color: '#ffffff60' },
});
