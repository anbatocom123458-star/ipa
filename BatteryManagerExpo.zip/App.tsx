import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import WelcomeScreen from './src/screens/WelcomeScreen';
import DashboardScreen from './src/screens/DashboardScreen';

export default function App() {
  const [hasSeenWelcome, setHasSeenWelcome] = useState<boolean | null>(null);

  useEffect(() => {
    AsyncStorage.getItem('@has_seen_welcome').then(val => {
      setHasSeenWelcome(val === 'true');
    });
  }, []);

  if (hasSeenWelcome === null) return <View style={styles.container} />;

  if (!hasSeenWelcome) {
    return <WelcomeScreen onComplete={() => setHasSeenWelcome(true)} />;
  }

  return <DashboardScreen />;
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0f0a' },
});
